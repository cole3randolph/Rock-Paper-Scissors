<html>
<!-- This html code sets the background color to a pleasing blue and displays a title-->
<h1>Rock Paper Scissors Simulator</h1>
<body style="background-color:#1c87c9;"> </body>
<!-- This html code creates a interactive box for the user to input their selection of either "Rock", "Paper", 
or "Scissors."-->
<form action="RPS1.php" method= "get">
    Enter Rock, Paper, or Scissors: <input type="text" name= "RPS">
    <button type="submit">Play</button>
    <br>
    You chose: <?php echo $_GET["RPS"] ?>
    <br>

<?php
//PHP code to obtain the player's entry
$pnum = $_GET['RPS'];
//PHP code to set variables to strings in order to process a players's entry
$rock = 'Rock';
$paper = 'Paper';
$scissors = 'Scissors';
//Series of if statements to compare the computer's random roll to the player's entry
if ($pnum == $rock) {
    //Randomly generated number 1-3 to represent rock, paper, and scissors
    $compnum = random_int(1,3);
    //Results communicated to the player
    if ($compnum == 1) {
        echo "The computer chose Rock! Replay the game for a winner.";
        
    }
    if ($compnum == 2) {
        echo "The computer chose Paper!";
        echo " You lost!";
    }
    if ($compnum == 3) {
        echo "The computer chose Scissors!";
        echo " You won!";
    }
}
//Sequence repeated for scissors
if ($pnum == $scissors) {
    $compnum = random_int(1,3);
    if ($compnum == 1) {
        echo "The computer chose Rock!";
        echo " You Lost!";
    }
    if ($compnum == 2) {
        echo "The computer chose Paper!";
        echo " You Won!";
    }
    if ($compnum == 3) {
        echo "The computer chose Scissors! Replay the game for a winner.";
    }
}
//Sequence repeated for paper
if ($pnum == $paper) {
    $compnum = random_int(1,3);
    if ($compnum == 1) {
        echo "The computer chose Rock!";
        echo " You won!";
    }
    if ($compnum == 2) {
        echo "The computer chose Paper! Replay the game for a winner.";
    }
    if ($compnum == 3) {
        echo "The computer chose Scissors!";
        echo " You lost!";
    }
}
?>

</html>